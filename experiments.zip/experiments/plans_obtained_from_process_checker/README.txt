Here we have, for every problem of folder ../plans_obtained_from_processMDPs, 
the correspondent optimal process plan with the same actions of that problem.

Example:

Makespan: 7 [9]
0: move_left robot0 tile4 tile3 [0]
0: move_left robot1 tile2 tile1 [0]
1: paint_tile robot1 black tile1 [0]
1: paint_tile robot0 black tile3 [0]
2: move_left robot1 tile1 tile0 [0]
2: move_right robot0 tile3 tile4 [0]
2: change_color robot0 black white [0]
3: paint_tile robot0 white tile4 [0]
3: change_color robot1 black white [-4]
4: move_left robot0 tile4 tile3 [0]
4: paint_tile robot1 white tile0 [-4]
5: move_left robot0 tile3 tile2 [0]
6: paint_tile robot0 white tile2 [0]

Means that the original plan (../plans_obtained_from_processMDPs/floortile/32.pddl) 
had a makespan of 9. The action (change_color robot1 black white) was originally
in timestep 7, and has been moved 4 timesteps earlier ([-4]). The new makespan
after downgrading all the actions is reduced to 7.